"""Photo-derived Heltec V3.2 / 50x70 perfboard enclosure, millimetres.

Requires cadquery, numpy, trimesh. All dimensions are editable below.
No electronics files are needed: the photographed prototype remains assembled.
"""
from pathlib import Path
import json, math
import cadquery as cq
import trimesh
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
PARTS = ROOT/'parts'
PARTS.mkdir(exist_ok=True)
(ROOT/'preview').mkdir(exist_ok=True)
(ROOT/'deliverables').mkdir(exist_ok=True)
W,L,H,R = 64.0,84.0,28.0,6.0
WALL,FLOOR,SEAM,ROOF = 2.0,2.0,16.0,2.0
BOARD_W,BOARD_L,BOARD_T,BOARD_TOP = 50.0,70.0,1.6,13.6
BOARD_BOTTOM = BOARD_TOP-BOARD_T
SWITCH_TOP = BOARD_TOP+4.5
BUTTONS = {'up':(5.5,-1.3),'left':(-7.2,-14.0),
           'center':(5.5,-14.0),'right':(18.2,-14.0),'down':(5.5,-26.7)}
SCREEN = (7.0,22.0,31.0,18.0)
LED = (-19.5,-27.5)
USB_Y,USB_Z = 19.5,21.6
STEM_LENGTHS = [5.5,5.9,6.3,6.7,7.1]
REPORT = {}
ASSEMBLY = []

def block(w,l,h,x=0,y=0,z=0):
    return cq.Workplane('XY').box(w,l,h,centered=(True,True,False)).translate((x,y,z))

def rr(w,l,r,h,z=0,x=0,y=0):
    q=block(w,l,h,x,y,z)
    return q.edges('|Z').fillet(r)

def cyl(d,h,x=0,y=0,z=0):
    return cq.Workplane('XY').circle(d/2).extrude(h).translate((x,y,z))

def emit(name,shape,assembled=None,style='shell'):
    s=shape.val()
    assert s.isValid(), name+' invalid CAD'
    assert len(shape.solids().vals())==1, name+' disconnected CAD'
    path=PARTS/(name+'.stl')
    cq.exporters.export(shape,str(path),tolerance=0.025,angularTolerance=0.10)
    mesh=trimesh.load(path,process=True)
    mesh.update_faces(mesh.unique_faces())
    f=mesh.faces
    mesh.update_faces((f[:,0]!=f[:,1])&(f[:,0]!=f[:,2])&(f[:,1]!=f[:,2]))
    mesh.remove_unreferenced_vertices()
    assert mesh.is_watertight and mesh.is_volume and mesh.is_winding_consistent, name
    assert len(mesh.split())==1, name+' mesh components'
    mesh.export(path)
    REPORT[name]={'path':str(path),'faces':len(mesh.faces),'watertight':True,
                  'volume_mm3':float(mesh.volume),'bounds_mm':mesh.bounds.tolist()}
    if assembled is not None:
        cq.exporters.export(assembled,str(PARTS/(name+'.step')))
        v,f=assembled.val().tessellate(0.04,0.1)
        ASSEMBLY.append({'name':name,'style':style,'vertices':np.array([p.toTuple() for p in v]),
                         'faces':np.array(f)})
    print(name, len(mesh.faces), 'faces; closed solid', flush=True)

# Base: generous wire cavity and four small edge saddles, no central pillars.
base=rr(W,L,R,SEAM).edges('<Z').chamfer(0.6)
base=base.cut(rr(W-4,L-4,R-2,SEAM+1,z=FLOOR))
for sx in [-1,1]:
    for yy in [-28.0,3.0]:
        # Seat touches the outermost 0.8 mm of the bare perfboard border.
        base=base.union(block(5.8,4.0,BOARD_BOTTOM-FLOOR,
                              x=sx*27.1,y=yy,z=FLOOR))
        # Vertical locator leaves 0.5 mm nominal XY clearance per side.
        base=base.union(block(4.5,4.0,1.85,
                              x=sx*27.75,y=yy,z=BOARD_BOTTOM))
for sy in [-1,1]:
    for xx in [0.0]:
        base=base.union(block(4.0,4.5,BOARD_TOP+0.25-FLOOR,
                              x=xx,y=sy*37.75,z=FLOOR))

# Four replaceable-by-reprinting integrated cantilever snap catches, at ends.
# Beam length 14 mm, thickness 1.2, engagement 0.4. End slots admit a thin pick.
for sy in [-1,1]:
    for xx in [-16.0,16.0]:
        base=base.cut(block(7.4,4.0,SEAM-2+0.1,x=xx,y=sy*41.0,z=2.0))
        beam=block(6.0,1.2,14.0,x=xx,y=sy*41.0,z=2.0)
        # YZ section: flat retention underside, 45-degree insertion lead.
        yz=[(40.4,12.7),(39.6,13.5),(39.2,13.5),(39.2,13.9),(40.4,15.1)]
        hook=cq.Workplane('YZ',origin=(xx-3,0,0)).polyline(yz).close().extrude(6.0)
        if sy<0: hook=hook.mirror('XZ')
        base=base.union(beam).union(hook)

# Lid: outside shell plus inward lip linking a short alignment skirt.
lid=rr(W,L,R,H-SEAM,z=SEAM).edges('>Z').chamfer(0.8)
lid=lid.cut(rr(W-4,L-4,R-2,H-SEAM+1,z=SEAM-1))
# Re-add roof because the preceding cavity passes through; face is a true 2mm slab.
roof=rr(W,L,R,ROOF,z=H-ROOF).edges('>Z').chamfer(0.8)
lid=lid.union(roof)
shoulder=rr(W,L,R,1.4,z=SEAM).cut(rr(56.4,76.4,2.2,2.0,z=SEAM-0.3))
skirt=rr(59.2,79.2,3.6,4.5,z=12.0).cut(rr(56.4,76.4,2.2,5.5,z=11.5))
lid=lid.union(shoulder).union(skirt)
# Taper the internal shoulder at 45 degrees for face-down support-free printing.
wire_low=rr(56.4,76.4,2.2,0.1,z=17.3).faces('>Z').wires().val()
wire_high=rr(60.0,80.0,4.0,0.1,z=19.1).faces('>Z').wires().val()
cavity_ramp=cq.Workplane('XY').newObject([cq.Solid.makeLoft([wire_low,wire_high],True)])
shoulder_ramp=rr(W,L,R,1.8,z=17.4).cut(cavity_ramp)
lid=lid.union(shoulder_ramp)
# Skirt reliefs clear the base's raised board locators during closure.
for sign in [-1,1]:
    for yy in [-28.0,3.0]:
        lid=lid.cut(block(5.0,5.2,2.5,x=sign*29.0,y=yy,z=11.6))
    lid=lid.cut(block(5.2,5.0,2.5,x=0,y=sign*39.0,z=11.6))
for sy in [-1,1]:
    for xx in [-16.0,16.0]:
        lid=lid.cut(block(6.8,4.0,2.2,x=xx,y=sy*39.0,z=13.3))

# Rounded USB opening through the left wall and the lip; enough for overmould.
usb=rr(14.0,9.0,1.4,15.0)
# local XY rectangle -> global YZ plane, extrusion points toward positive X.
usb=usb.rotate((0,0,0),(0,1,0),90).rotate((0,0,0),(1,0,0),90)
# After rotations: local x -> +Y, local y -> +Z, extrusion -> +X.
usb=usb.translate((-38.0,USB_Y,USB_Z))
lid=lid.cut(usb)
base=base.cut(usb)

# Antenna pigtail: side slot open to seam, so attached SMA need not pass through.
antenna=block(15.0,4.5,11.4,x=31,y=29,z=11.5)
roundtop=cq.Workplane('YZ',origin=(24,29,22.9)).circle(2.25).extrude(15)
antenna=antenna.union(roundtop)
lid=lid.cut(antenna)

# Screen bezel opening and softly flared top edge (no contact with glass).
sx,sy,sw,sh=SCREEN
lid=lid.cut(rr(sw,sh,1.4,5,z=25,x=sx,y=sy))
lid=lid.cut(rr(sw+0.8,sh+0.8,1.8,0.5,z=H-0.45,x=sx,y=sy))
# Recessed LED indicator aperture. The existing LED remains below the face.
lid=lid.cut(cyl(6.4,8,*LED,z=22))
lid=lid.cut(cyl(7.4,0.45,*LED,z=H-0.4))

# Straight push buttons insert from inside. No exterior head blocks assembly.
for name,(x,y) in BUTTONS.items():
    lid=lid.cut(cyl(9.0,6,x,y,z=24))
    lid=lid.cut(cyl(9.6,0.4,x,y,z=H-0.35))

# Four discreet board retainers align with the base's edge support pads.
for sign in [-1,1]:
    for yy in [-28.0,3.0]:
        lid=lid.union(block(5.4,3.6,SEAM+1.4-14.2,
                            x=sign*26.9,y=yy,z=14.2))
        lid=lid.union(block(0.9,3.6,SEAM+1.4-(BOARD_TOP+0.25),
                            x=sign*24.65,y=yy,z=BOARD_TOP+0.25))
        # Triangular web begins at the side wall when printed face-down;
        # new material grows inward at 45 degrees instead of over open air.
        web=cq.Workplane('XZ',origin=(0,yy+1.8,0)).polyline(
            [(24.2,17.4),(30.05,17.4),(30.05,23.25)]).close().extrude(3.6)
        if sign<0: web=web.mirror('YZ')
        lid=lid.union(web)
lid=lid.cut(antenna)

shell_collision=base.val().intersect(lid.val()).Volume()
print('Assembled shell intersection volume:',shell_collision,flush=True)
assert shell_collision<1e-5, 'Base/lid collision'

# Emit shell components with support-free print orientations.
emit('01_base',base,base,'base')
lid_print=lid.rotate((0,0,0),(1,0,0),180).translate((0,0,H))
emit('02_lid_face_down',lid_print,lid,'lid')

def button(kind,stem):
    # Assembly coordinates, centered XY. Neck protrudes at most 0.8mm.
    part=cyl(8.4,4.4,z=24.4)
    # Retention flange tapers to support printing face-down without support.
    flange=cq.Workplane('XY',origin=(0,0,24.4)).circle(5.6).workplane(offset=1.4).circle(4.2).loft()
    part=part.union(flange).union(cyl(4.2,stem+0.15,z=24.4-stem))
    # One to five edge notches identify reach after parts leave the print bed.
    reach_id=STEM_LENGTHS.index(stem)+1
    for k in range(reach_id):
        notch=block(1.6,0.75,0.85,x=5.55,z=24.3)
        notch=notch.rotate((0,0,0),(0,0,1),k*26)
        part=part.cut(notch)
    if kind=='center':
        mark=cyl(2.1,0.5,z=28.45)
    else:
        pts=[(-1.65,-0.7),(1.65,-0.7),(0,1.7)]
        angle={'up':0,'right':-90,'down':180,'left':90}[kind]
        mark=cq.Workplane('XY').polyline(pts).close().extrude(0.5).translate((0,0,28.45))
        mark=mark.rotate((0,0,0),(0,0,1),angle)
    return part.cut(mark)

for n,stem in enumerate(STEM_LENGTHS):
    for kind,xy in BUTTONS.items():
        btn=button(kind,stem)
        printshape=btn.rotate((0,0,0),(1,0,0),180).translate((0,0,28.8))
        ident=f'button_{stem:.1f}_{kind}'
        assembled=btn.translate((*xy,0)) if abs(stem-6.3)<0.01 else None
        if assembled is not None:
            assert assembled.val().intersect(lid.val()).Volume()<1e-5
        emit(ident,printshape,assembled,'button')

# Cheap visual alignment stencil: rests above electronics, not forced down.
# Outline matches 50x70 board; open display + switch inspection holes.
gauge=rr(54,74,3,0.8).cut(rr(50.6,70.6,1.3,2,z=-0.5))
for kind,(x,y) in BUTTONS.items():
    gauge=gauge.union(cyl(9.0,0.8,x,y)).cut(cyl(5.4,2,x,y,z=-0.5))
    # Narrow connected branches to the outline, all clear of switch sight holes.
    if x>=0:
        gauge=gauge.union(block(27-x,1.6,0.8,x=(x+27)/2,y=y))
    else:
        gauge=gauge.union(block(x+27,1.6,0.8,x=(x-27)/2,y=y))
    gauge=gauge.cut(cyl(5.4,2,x,y,z=-0.5))
# Outline the window with connected frame and two side ties.
frame=rr(sw+2,sh+2,2.2,0.8,x=sx,y=sy).cut(rr(sw,sh,1.2,2,z=-0.5,x=sx,y=sy))
gauge=gauge.union(frame).union(block(7,1.6,0.8,x=23.5,y=sy))
gauge=gauge.union(block(5,1.6,0.8,x=-24.5,y=sy))
# Connect the left window frame to the board outline across the free gap.
gauge=gauge.union(block(18,1.6,0.8,x=-18,y=sy))
emit('00_fit_stencil',gauge)

(ROOT/'geometry_validation.json').write_text(json.dumps(REPORT,indent=2))
params={k:v for k,v in globals().copy().items() if k in ['W','L','H','R','WALL','FLOOR','SEAM','ROOF','BOARD_W','BOARD_L','BOARD_T','BOARD_TOP','BUTTONS','SCREEN','LED','USB_Y','USB_Z','STEM_LENGTHS']}
(ROOT/'parameters.json').write_text(json.dumps(params,indent=2))
np.savez_compressed(ROOT/'preview'/'assembled_meshes.npz',
                    **{f'{i}_{k}':v for i,obj in enumerate(ASSEMBLY) for k,v in obj.items()})
assembly=cq.Assembly(name='LoRa_Handheld')
assembly.add(base,name='base')
assembly.add(lid,name='lid')
for name,xy in BUTTONS.items():
    assembly.add(button(name,6.3).translate((*xy,0)),name='button_'+name)
assembly.save(str(ROOT/'deliverables'/'LoRa_Handheld_Assembly.step'))
print('All parts complete.',flush=True)
