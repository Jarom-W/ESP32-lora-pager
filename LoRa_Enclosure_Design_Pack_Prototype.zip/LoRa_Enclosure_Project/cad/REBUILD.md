# Rebuilding the case

The supplied 3MF projects are already oriented and sliced for an A1 with a 0.4 mm nozzle and PLA. The CAD source is included for future fit changes.

Install the Python requirements in this folder, then run `python cad/build_enclosure.py` from the project folder. The generator writes the individual STLs to `parts/`, an assembled STEP to `deliverables/`, a dimensional record to `parameters.json`, and a geometry report. It checks each part for a closed, consistently oriented solid and checks that the lid and base do not overlap in their assembled positions.

Edit the constants and coordinate dictionaries at the top of `build_enclosure.py`. `parameters.json` is a generated dimensional record, not the input configuration. All lengths are millimetres. The CAD XY origin is the center of the nominal 50 x 70 mm perfboard. To convert the guide's lower-left coordinates, subtract 25 from X and 35 from Y.

Changing a local feature in CAD preserves other fit dimensions. Do not scale the whole 3MF to correct one button or port. After changing the CAD, import the new oriented STLs into Bambu Studio and slice again; the Python generator does not overwrite the supplied native 3MF projects or their G-code.

The STL lid and buttons are already face-down for printing. The STEP files show their assembled orientation. The five reach variants are identified by 1-5 flange-edge notches, shortest to longest. Keep `cad/`, `parts/`, `preview/`, and `deliverables/` under one project root when rebuilding. Create the latter folders if missing.

This is a photo-derived first-fit design. The source preserves the measured assumptions so that an actual fit report can be used for precise revisions.
