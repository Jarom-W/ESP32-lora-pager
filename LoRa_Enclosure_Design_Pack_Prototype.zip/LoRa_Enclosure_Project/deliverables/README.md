# LoRa handheld enclosure - prototype V1

Custom photo-derived enclosure for the photographed Heltec WiFi LoRa 32 V3.2 and five-button perfboard assembly. **Fit has not been physically tested.** Print the alignment stencil first.

## Package

- `LoRa_Handheld_A1.3mf`: base, face-down lid, and 25 button plungers (five directions in each of five stem lengths).
- `LoRa_Fit_Check_A1.3mf`: a low-material alignment stencil only.
- `LoRa_Handheld_Assembly.step`: assembled CAD reference; not the arranged print plate.
- `LoRa_Enclosure_Assembly_Guide.pdf`: illustrated print, fit, and assembly instructions.

## Geometry

- Shell: **64 x 84 x 28 mm**; buttons project **about 0.8 mm in the nominal assembly**. Their resting position can vary with actual switch height.
- Perfboard: estimated **50 x 70 x 1.6 mm**.
- Base floor: 2 mm. Board underside: Z = 12 mm. Board top: Z = 13.6 mm. Nominal wire space below board: 10 mm.
- Board supports: four small edge saddles, positive locators, and lid retainers with 0.25 mm nominal clearance above the board.
- Openings: display 31 x 18 mm, LED diameter 6.4 mm, left USB-C 14 x 9 mm.
- Right antenna exit: 4.5 mm wide pigtail slot open to the seam; route the attached lead into the notch. The case does not mount the SMA connector as a rigid bulkhead.
- Four integral end-wall snap clips; no screws. No battery compartment is modeled.

## Printing

Bambu Lab A1, 0.4 mm nozzle, PLA, 0.16 mm layers, four shell walls, no supports. Project parts are oriented with the base upright, lid exterior face down, and button faces down. Print only the needed button set if desired; keep alternate lengths available for fitting. Confirm the active filament and plate in Bambu Studio and inspect the sliced preview before sending the job.

**Preview colors are illustrative. The default 3MF uses one filament color.** Button caps can be printed separately in a contrasting color if desired.

The five button rows nearest the shell parts through farthest are 5.5, 5.9, 6.3, 6.7, and 7.1 mm stems. Columns from left to right are Up, Left, Center, Right, and Down. Once removed from the plate, identify length by the **1-5 small notches in the flange edge**, from shortest to longest. Nominal/default 6.3 mm stems have three notches; this is not a verified fit.

## Fit check

The stencil is 54 x 74 mm overall with a 50.6 x 70.6 mm board-outline opening, five switch sight holes, and a screen opening. Hold it centered above the board, then compare the actual switch centers and screen against it. **Do not force it down over components.** The geometry is based on photos; allow roughly 1 mm positional uncertainty, and expect switch-height tuning.

## Assembly

1. Seat the perfboard on the four edge saddles. Keep wire loops and solder joints away from the supports, locators, and clips.
2. Route the antenna pigtail through the right-side seam notch. Do not pinch the cable or pull the board's tiny antenna connector.
3. Insert five plungers from inside the lid; their larger retention flanges remain inside. Use arrows for the four directions and the dot for center. Removable tape across the outside faces can hold them during assembly.
4. Start with the shortest **5.5 mm** stems and increase length only if needed. Hold the lid fully seated before snapping it closed. Choose the shortest stem that clicks reliably and returns freely. Available lengths are **5.5, 5.9, 6.3, 6.7, and 7.1 mm**; 6.3 mm is the nominal/default length, not a verified fit. A stem that holds a switch down is too long.
5. Confirm USB-plug, display, LED, and cable clearance. Gently engage the four end-wall clips, remove tape, and recheck all buttons. Stop if closing requires force.
6. To reopen, use a thin plastic pick in the end-wall clip slots and release clips individually while gently lifting the lid. Avoid levering against electronics.

## Photo-derived feature centers

Coordinates use the **lower-left corner of the front/component side of the 50 x 70 mm board**. X points right; Y points up toward the display. Units: mm.

| Feature | X | Y |
| --- | ---: | ---: |
| Up switch | 30.5 | 33.7 |
| Left switch | 17.8 | 21.0 |
| Center switch | 30.5 | 21.0 |
| Right switch | 43.2 | 21.0 |
| Down switch | 30.5 | 8.3 |
| LED | 5.5 | 7.5 |
| Display-window center | 32.0 | 57.0 |

The model's native XY origin is at the board center, so add 25 to CAD X and 35 to CAD Y to obtain these corner-based coordinates. Do not resize the entire project in the slicer to fix a local mismatch: this would change all opening, button, and snap dimensions together.

## Reference

[Heltec WiFi LoRa 32 V3.2 official module drawing](https://resource.heltec.cn/download/WiFi_LoRa_32_V3/HTIT-WB32LA_V3.2.pdf). The drawing describes the module; the perfboard, wiring, and button placement come from the supplied prototype photographs.
